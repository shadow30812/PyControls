import unittest
from typing import Any, Optional

import numpy as np
from numpy.typing import NDArray

from core.ekf import ExtendedKalmanFilter
from core.solver import _mat_mul, manual_matrix_exp


class TestJITAndVectorization(unittest.TestCase):
    """
    Tests specifically targeting the JIT compiled functions and vectorization logic.
    Ensures numerical correctness of custom implementations (replacing SciPy).
    """

    def test_manual_matrix_mul_correctness(self) -> None:
        """
        Verify the custom JIT matrix multiplication against NumPy's dot product.
        This is critical since @ has been replaced by _mat_mul for Numba compatibility.
        """
        np.random.seed(123)
        A = np.random.rand(5, 5)
        B = np.random.rand(5, 5)

        expected = A @ B
        result = _mat_mul(A, B)

        np.testing.assert_array_almost_equal(result, expected, decimal=12)

    def test_manual_matrix_mul_nonsquare(self) -> None:
        """Verify _mat_mul handles non-square matrices correctly."""
        A = np.zeros((2, 3))
        A[0, 0] = 1.0
        A[1, 1] = 1.0

        B = np.ones((3, 2))

        expected = A @ B
        result = _mat_mul(A, B)

        np.testing.assert_array_almost_equal(result, expected)

    def test_matrix_exp_properties(self) -> None:
        """
        Verify properties of Matrix Exponential e^A.
        1. e^(A+B) = e^A * e^B if AB = BA (e.g. diagonal matrices)
        2. det(e^A) = e^trace(A)
        """
        A = np.diag([1.0, 2.0])
        B = np.diag([3.0, 4.0])

        expA = manual_matrix_exp(A)
        expB = manual_matrix_exp(B)
        expAB = manual_matrix_exp(A + B)

        prod = _mat_mul(expA, expB)
        np.testing.assert_array_almost_equal(prod, expAB)

        det_expA = np.linalg.det(expA)
        exp_traceA = np.exp(np.trace(A))
        self.assertAlmostEqual(det_expA, exp_traceA)

    def test_ekf_vectorization_throughput(self) -> None:
        """
        Verify that the vectorized EKF Jacobian computation returns
        the correct shape and values for a larger state vector.
        """
        x0 = np.arange(10, dtype=float)

        def f_vec(x: NDArray[np.float64], u: Optional[Any] = None) -> NDArray[Any]:
            return 2.0 * x

        h = lambda x: x

        ekf = ExtendedKalmanFilter(f_vec, h, np.eye(10), np.eye(10), x0)

        J = ekf.compute_jacobian(f_vec, x0)

        expected_J = np.eye(10) * 2.0

        np.testing.assert_array_almost_equal(J, expected_J)
        self.assertEqual(J.shape, (10, 10))


if __name__ == "__main__":
    unittest.main()
